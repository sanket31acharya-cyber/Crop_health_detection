# Crop Disease Detection using Deep Learning
Full project with training, evaluation, Grad-CAM, and instructions.
